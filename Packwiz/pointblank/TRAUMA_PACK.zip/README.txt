This is Trauma for Vic's Point Blank

Trauma is a Firearms Pack that is Based in mostly from Beginning of the Victorian Colonialism to the Early Cold War and Decolonization with those being based from the Crimean Wars (1853-1856) to Suez Crisis (1956) my main focus at the moment would be the First World War.

WE NEED YOU FOR THE WAR EFFORT:
I am looking at people who might be interested in contributing to trauma, specfically animators and texture artists if you are interested join the Vic's Point Blank Discord (https://discord.gg/DUU785aR4Q) and contact me on display discord my name is Teufelsbann.

Current National Firearms Count:
British Empire - 3
United States of America - 3
German Empire - 5
French Third Republic - 3
Russian Empire - 3
Austro-Hungary - 3
Italian Empire - 2
Japanese Empire - 1
Ottoman Empire - 1

I generally try to be historically accurate but may bend some accuracy for gameplay reasons, if there is a historical inaccuracy i probably know what it is especially if such is blatant but still do feel free to comment and suggest. 

if you find any problems please contact me through the comments but if you join the discord i may be able to help you better.